import json
from urllib.parse import unquote_plus

def parse_s3_records(records):
    """Return unique S3 object references from S3->SQS event messages."""
    result = []
    seen = set()
    for record in records:
        body = record.get("body", "")
        try:
            event = json.loads(body)
        except json.JSONDecodeError:
            continue
        for item in event.get("Records", []):
            if item.get("eventSource") != "aws:s3":
                continue
            bucket = item.get("s3", {}).get("bucket", {}).get("name")
            key = item.get("s3", {}).get("object", {}).get("key")
            version_id = item.get("s3", {}).get("object", {}).get("versionId")
            if not bucket or not key:
                continue
            key = unquote_plus(key)
            identity = (bucket, key, version_id)
            if identity not in seen:
                seen.add(identity)
                result.append({
                    "bucket": bucket, "key": key,
                    "version_id": version_id,
                    "event_time": item.get("eventTime"),
                    "event_name": item.get("eventName"),
                    "s3_sequencer": item.get("s3", {}).get("object", {}).get("sequencer"),
                })
    return result
