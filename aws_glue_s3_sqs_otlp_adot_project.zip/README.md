# AWS Glue S3 file monitoring -> SQS -> Glue Streaming -> OTLP -> ADOT -> X-Ray + Dynatrace

## Important
S3 is not used as the native Glue Streaming source. S3 ObjectCreated events go to SQS. The Glue streaming job reads the SQS event messages and processes the referenced S3 files. For production, prefer an AWS-supported event/streaming integration and validate the exact Glue runtime/API in your account.

## Architecture
S3 ObjectCreated -> SQS -> Glue Streaming -> S3 output
                              |
                              +-> OTLP -> external ADOT Collector -> X-Ray
                                                    |
                                                    +-> Dynatrace

## Reliability
- SQS message is deleted only after successful S3 processing.
- If processing fails, the message is left in SQS and becomes visible again after VisibilityTimeout.
- Traces are force-flushed at the end of each batch.
- A hard process/node failure can still lose telemetry that was not exported before the failure.
- Run ADOT outside Glue so collector failure/lifecycle is independent of the Spark process.
- Configure an SQS DLQ/redrive policy for poison messages.

## Glue arguments
--JOB_NAME my-s3-stream
--SQS_QUEUE_URL https://sqs.us-east-1.amazonaws.com/123456789012/my-s3-events
--OUTPUT_PATH s3://my-bucket/processed/
--CHECKPOINT_PATH s3://my-bucket/checkpoints/my-s3-stream/
--OTEL_ENDPOINT https://adot.example.com:4318
--ENVIRONMENT prod
--WINDOW_SIZE 60 seconds

## S3 notification
Configure the S3 bucket ObjectCreated notification to the SQS queue. Restrict events to the intended prefix/suffix where possible, and grant S3 permission to send to SQS.

## IAM
Glue role needs read access to input S3, write access to output/checkpoint S3, receive/delete/change visibility access on the SQS queue, and network access to the ADOT OTLP endpoint. The ADOT role needs X-Ray write permissions. Dynatrace API token needs OTLP ingest permission.

## Duplicate processing
S3 events and SQS are at-least-once. A message can be delivered more than once. This sample demonstrates event monitoring and safe delete-after-success, but output writes are not fully idempotent. For production, use S3 object version ID/ETag as an idempotency key and persist processed keys in DynamoDB or another durable store before treating the file as complete.

## File formats
The sample reads JSON. Change spark.read.json() to parquet/csv/etc. as needed.

## Testing
Syntax validation:
python -m py_compile otel_tracer.py s3_event_parser.py glue_s3_stream_job.py s3_batch_job.py

An AWS account integration test is still required for Glue, S3, SQS, ADOT, X-Ray and Dynatrace.
