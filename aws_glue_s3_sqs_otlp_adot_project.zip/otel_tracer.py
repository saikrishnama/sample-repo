import os
from contextlib import contextmanager
from opentelemetry import trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter

_tracer_provider = None
_tracer = None

def init_tracing(job_name, job_run_id, environment, otlp_endpoint, service_name=None):
    global _tracer_provider, _tracer
    if _tracer_provider is not None:
        return _tracer
    endpoint = otlp_endpoint.rstrip("/") + "/v1/traces"
    resource = Resource.create({
        "service.name": service_name or job_name,
        "deployment.environment.name": environment,
        "aws.glue.job.name": job_name,
        "aws.glue.job.run_id": job_run_id,
    })
    exporter = OTLPSpanExporter(endpoint=endpoint, timeout=10)
    provider = TracerProvider(resource=resource)
    provider.add_span_processor(BatchSpanProcessor(
        exporter, max_queue_size=2048, max_export_batch_size=128,
        schedule_delay_millis=2000, export_timeout_millis=8000
    ))
    trace.set_tracer_provider(provider)
    _tracer_provider = provider
    _tracer = trace.get_tracer(__name__)
    return _tracer

def tracer():
    if _tracer is None:
        raise RuntimeError("Call init_tracing() first")
    return _tracer

@contextmanager
def trace_operation(name, **attributes):
    with tracer().start_as_current_span(name) as span:
        for k, v in attributes.items():
            if v is not None:
                span.set_attribute(k, str(v))
        try:
            yield span
        except Exception as exc:
            span.record_exception(exc)
            span.set_attribute("error.type", type(exc).__name__)
            span.set_status(trace.Status(trace.StatusCode.ERROR, str(exc)))
            raise

def flush_traces(timeout_seconds=5):
    if _tracer_provider is not None:
        return _tracer_provider.force_flush(timeout_millis=timeout_seconds * 1000)
    return True

def shutdown_tracing(timeout_seconds=5):
    if _tracer_provider is not None:
        return _tracer_provider.shutdown()
