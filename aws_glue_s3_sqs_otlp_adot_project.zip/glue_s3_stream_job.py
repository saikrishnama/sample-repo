import sys, json, time, boto3
from pyspark.sql import functions as F
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext

from otel_tracer import init_tracing, trace_operation, flush_traces
from s3_event_parser import parse_s3_records

REQUIRED = [
    "JOB_NAME","SQS_QUEUE_URL","OUTPUT_PATH","CHECKPOINT_PATH",
    "OTEL_ENDPOINT","ENVIRONMENT","WINDOW_SIZE"
]
args = getResolvedOptions(sys.argv, REQUIRED)
sc = SparkContext()
glue_context = GlueContext(sc)
spark = glue_context.spark_session
job = Job(glue_context)
job.init(args["JOB_NAME"], args)

job_run_id = args.get("JOB_RUN_ID", "unknown")
init_tracing(args["JOB_NAME"], job_run_id, args["ENVIRONMENT"], args["OTEL_ENDPOINT"])

sqs = boto3.client("sqs")
s3 = boto3.client("s3")

def delete_messages(messages):
    entries = [{"Id": str(i), "ReceiptHandle": m["receipt_handle"]}
               for i, m in enumerate(messages)]
    for start in range(0, len(entries), 10):
        sqs.delete_message_batch(
            QueueUrl=args["SQS_QUEUE_URL"],
            Entries=entries[start:start+10]
        )

def process_batch(batch_df, batch_id):
    started = time.time()
    messages = []
    refs = []
    with trace_operation("glue.s3.file_batch",
                         **{"aws.glue.batch.id": batch_id,
                            "aws.sqs.queue.url": args["SQS_QUEUE_URL"]}) as span:
        try:
            response = sqs.receive_message(
                QueueUrl=args["SQS_QUEUE_URL"],
                MaxNumberOfMessages=10,
                WaitTimeSeconds=1,
                VisibilityTimeout=900,
                MessageAttributeNames=["All"],
                AttributeNames=["All"],
            )
            raw = response.get("Messages", [])
            messages = [{"receipt_handle": m["ReceiptHandle"], "body": m["Body"]} for m in raw]
            refs = parse_s3_records(raw)
            span.set_attribute("s3.file.count", len(refs))

            for ref in refs:
                with trace_operation("s3.file.process",
                    **{"aws.s3.bucket": ref["bucket"],
                       "aws.s3.object.key": ref["key"],
                       "aws.s3.event.time": ref["event_time"]}):
                    head = s3.head_object(Bucket=ref["bucket"], Key=ref["key"])
                    size = head.get("ContentLength", 0)
                    if size == 0:
                        raise ValueError(f"Empty S3 object: s3://{ref['bucket']}/{ref['key']}")

                    input_path = f"s3://{ref['bucket']}/{ref['key']}"
                    df = spark.read.json(input_path)
                    count = df.count()
                    if count:
                        output = df.withColumn("_source_file", F.lit(ref["key"]))                                    .withColumn("_processed_at", F.current_timestamp())
                        output.write.mode("append").parquet(args["OUTPUT_PATH"])
                    else:
                        span.set_attribute("s3.file.empty_records", True)
            delete_messages(messages)
            span.set_attribute("s3.files.processed", len(refs))
            span.set_attribute("processing.seconds", time.time() - started)
        except Exception:
            # Do NOT delete SQS messages. Visibility timeout allows retry.
            span.set_attribute("sqs.messages.requeued", len(messages))
            raise
        finally:
            # Export completed telemetry before returning from this micro-batch.
            flush_traces(5)

glue_context.forEachBatch(
    frame=None,
    batch_function=process_batch,
    options={
        "windowSize": args["WINDOW_SIZE"],
        "checkpointLocation": args["CHECKPOINT_PATH"],
        "batchMaxRetries": 3,
    },
)
