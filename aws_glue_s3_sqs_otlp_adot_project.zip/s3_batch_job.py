import sys
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from pyspark.sql import functions as F
from otel_tracer import init_tracing, trace_operation, flush_traces

args = getResolvedOptions(sys.argv, [
    "JOB_NAME","INPUT_PATH","OUTPUT_PATH","OTEL_ENDPOINT","ENVIRONMENT"
])
sc = SparkContext()
glue_context = GlueContext(sc)
spark = glue_context.spark_session
job = Job(glue_context)
job.init(args["JOB_NAME"], args)
init_tracing(args["JOB_NAME"], args.get("JOB_RUN_ID","unknown"),
             args["ENVIRONMENT"], args["OTEL_ENDPOINT"])

try:
    with trace_operation("glue.s3.batch",
                         **{"aws.s3.input.path": args["INPUT_PATH"],
                            "aws.s3.output.path": args["OUTPUT_PATH"]}):
        df = spark.read.json(args["INPUT_PATH"])
        output = df.withColumn("_processed_at", F.current_timestamp())
        output.write.mode("append").parquet(args["OUTPUT_PATH"])
finally:
    flush_traces(5)
    job.commit()
