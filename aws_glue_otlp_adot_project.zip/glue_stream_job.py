"""AWS Glue Streaming job: Kinesis -> Spark -> Amazon S3.

This uses the AWS Glue streaming API (forEachBatch). AWS Glue managed
streaming sources are Kinesis, Kafka, and MSK. S3 is a supported streaming
TARGET, not a managed streaming source.
"""

from __future__ import annotations

import logging
import sys

from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from pyspark.sql import DataFrame
from pyspark.sql.functions import col, current_timestamp, from_json
from pyspark.sql.types import StringType, StructField, StructType

from otel_tracer import flush_traces, init_tracing, trace_operation

logging.basicConfig(level=logging.INFO)
LOG = logging.getLogger(__name__)


def get_args():
    return getResolvedOptions(
        sys.argv,
        [
            "JOB_NAME",
            "KINESIS_STREAM_ARN",
            "OUTPUT_PATH",
            "CHECKPOINT_PATH",
            "OTEL_ENDPOINT",
            "ENVIRONMENT",
            "WINDOW_SIZE",
            "BATCH_MAX_RETRIES",
        ],
    )


EVENT_SCHEMA = StructType(
    [
        StructField("event_id", StringType(), True),
        StructField("customer_id", StringType(), True),
        StructField("event_type", StringType(), True),
        StructField("event_time", StringType(), True),
    ]
)


def transform_batch(batch_df: DataFrame) -> DataFrame:
    """Parse JSON Kinesis records and add a processing timestamp."""
    return (
        batch_df.select(from_json(col("data").cast("string"), EVENT_SCHEMA).alias("event"))
        .select("event.*")
        .withColumn("processed_at", current_timestamp())
    )


def main() -> None:
    args = get_args()

    sc = SparkContext.getOrCreate()
    glue_context = GlueContext(sc)
    spark = glue_context.spark_session

    job = Job(glue_context)
    job.init(args["JOB_NAME"], args)

    # JOB_RUN_ID is a Glue-reserved runtime argument. It is available in the
    # Glue process arguments even though it is not one of our custom arguments.
    run_args = getResolvedOptions(sys.argv, ["JOB_RUN_ID"])
    job_run_id = run_args["JOB_RUN_ID"]

    init_tracing(
        job_name=args["JOB_NAME"],
        job_run_id=job_run_id,
        environment=args["ENVIRONMENT"],
        otlp_endpoint=args["OTEL_ENDPOINT"],
    )

    LOG.info("Starting Glue streaming job: %s / %s", args["JOB_NAME"], job_run_id)

    kinesis_options = {
        "streamARN": args["KINESIS_STREAM_ARN"],
        "startingPosition": "LATEST",
        "inferSchema": "true",
        "classification": "json",
    }

    streaming_df = glue_context.create_data_frame.from_options(
        connection_type="kinesis",
        connection_options=kinesis_options,
        transformation_ctx="kinesis_source",
    )

    def process_batch(batch_df: DataFrame, batch_id: int) -> None:
        with trace_operation(
            "glue.streaming.micro_batch",
            batch_id=int(batch_id),
            source_type="kinesis",
            target_type="s3",
        ) as span:
            try:
                record_count = batch_df.count()
                span.set_attribute("aws.glue.batch.input_records", int(record_count))
                span.set_attribute("aws.glue.batch.id", int(batch_id))

                if record_count == 0:
                    span.set_attribute("aws.glue.batch.status", "empty")
                    return

                transformed = transform_batch(batch_df)

                (
                    transformed.write
                    .mode("append")
                    .format("parquet")
                    .save(args["OUTPUT_PATH"])
                )

                span.set_attribute("aws.glue.batch.status", "success")
                span.set_attribute("aws.glue.batch.output_path", args["OUTPUT_PATH"])
            except Exception as exc:
                span.set_attribute("aws.glue.batch.status", "failed")
                span.record_exception(exc)
                raise
            finally:
                # Do not wait for the streaming job to terminate before sending
                # telemetry. This is especially useful when a later batch fails.
                flush_traces(5)

    try:
        glue_context.forEachBatch(
            frame=streaming_df,
            batch_function=process_batch,
            options={
                "windowSize": args["WINDOW_SIZE"],
                "checkpointLocation": args["CHECKPOINT_PATH"],
                "batchMaxRetries": int(args["BATCH_MAX_RETRIES"]),
            },
        )
    except Exception as exc:
        LOG.exception("Glue streaming job failed")
        with trace_operation("glue.streaming.job_failure") as span:
            span.set_attribute("aws.glue.job.status", "failed")
            span.record_exception(exc)
        flush_traces(10)
        raise
    finally:
        flush_traces(10)

    job.commit()


if __name__ == "__main__":
    main()
