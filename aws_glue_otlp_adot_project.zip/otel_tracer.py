"""Small OpenTelemetry tracing wrapper for AWS Glue jobs.

The Glue job imports this module and does not need to know about OTLP details.
Designed for an external ADOT Collector reachable over OTLP/HTTP.
"""

from __future__ import annotations

import atexit
import logging
import os
import socket
from contextlib import contextmanager
from typing import Iterator, Optional

from opentelemetry import trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter

LOG = logging.getLogger(__name__)

_PROVIDER: Optional[TracerProvider] = None
_TRACER = None


def _env_bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "y"}


def init_tracing(
    job_name: str,
    job_run_id: str,
    environment: str = "unknown",
    otlp_endpoint: Optional[str] = None,
) -> None:
    """Initialize the process-wide tracer once.

    OTLP endpoint should be the collector's HTTP trace endpoint, e.g.
    https://adot.example.internal:4318/v1/traces
    """
    global _PROVIDER, _TRACER

    if _TRACER is not None:
        return

    endpoint = otlp_endpoint or os.getenv("OTEL_EXPORTER_OTLP_TRACES_ENDPOINT")
    if not endpoint:
        raise ValueError("OTLP trace endpoint is required")

    service_name = os.getenv("OTEL_SERVICE_NAME", job_name)

    resource = Resource.create(
        {
            "service.name": service_name,
            "service.version": os.getenv("SERVICE_VERSION", "1.0.0"),
            "deployment.environment.name": environment,
            "aws.glue.job.name": job_name,
            "aws.glue.job.run_id": job_run_id,
            "host.name": socket.gethostname(),
        }
    )

    provider = TracerProvider(resource=resource)

    # Five seconds keeps telemetry reasonably fresh while avoiding an OTLP
    # network call for every single span.
    schedule_delay_ms = int(os.getenv("OTEL_BSP_SCHEDULE_DELAY_MILLIS", "5000"))
    max_export_batch_size = int(os.getenv("OTEL_BSP_MAX_EXPORT_BATCH_SIZE", "128"))
    max_queue_size = int(os.getenv("OTEL_BSP_MAX_QUEUE_SIZE", "2048"))
    export_timeout_ms = int(os.getenv("OTEL_EXPORTER_OTLP_TIMEOUT", "5000"))

    headers = {}
    header_string = os.getenv("OTEL_EXPORTER_OTLP_HEADERS", "")
    for item in header_string.split(","):
        if "=" in item:
            key, value = item.split("=", 1)
            headers[key.strip()] = value.strip()

    exporter = OTLPSpanExporter(
        endpoint=endpoint,
        headers=headers or None,
        timeout=export_timeout_ms / 1000,
    )

    processor = BatchSpanProcessor(
        exporter,
        schedule_delay_millis=schedule_delay_ms,
        max_export_batch_size=max_export_batch_size,
        max_queue_size=max_queue_size,
        export_timeout_millis=export_timeout_ms,
    )
    provider.add_span_processor(processor)

    trace.set_tracer_provider(provider)
    _PROVIDER = provider
    _TRACER = trace.get_tracer("aws-glue-streaming")

    # Best effort only. The job should not fail because telemetry cannot flush.
    atexit.register(shutdown_tracing)
    LOG.info("OpenTelemetry initialized: endpoint=%s job=%s run=%s", endpoint, job_name, job_run_id)


def get_tracer():
    if _TRACER is None:
        raise RuntimeError("Call init_tracing() before get_tracer()")
    return _TRACER


@contextmanager
def trace_operation(name: str, **attributes) -> Iterator[object]:
    """Trace a logical operation and record exceptions."""
    span = get_tracer().start_span(name)
    try:
        for key, value in attributes.items():
            if value is not None:
                span.set_attribute(key, value)
        yield span
    except Exception as exc:
        span.record_exception(exc)
        span.set_status(trace.Status(trace.StatusCode.ERROR, str(exc)))
        raise
    finally:
        span.end()


def flush_traces(timeout_seconds: float = 5.0) -> bool:
    """Force buffered spans to the ADOT collector.

    Call this at the end of each streaming micro-batch. It reduces the amount
    of telemetry that can remain only in the Glue process when a failure occurs.
    """
    if _PROVIDER is None:
        return True
    try:
        return bool(_PROVIDER.force_flush(int(timeout_seconds * 1000)))
    except Exception:
        LOG.exception("Failed to flush OpenTelemetry spans")
        return False


def shutdown_tracing() -> None:
    if _PROVIDER is None:
        return
    try:
        _PROVIDER.shutdown()
    except Exception:
        LOG.exception("Failed to shut down OpenTelemetry")
