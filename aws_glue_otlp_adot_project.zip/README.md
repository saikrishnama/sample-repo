# AWS Glue + OTLP + ADOT + X-Ray/Dynatrace

## Important AWS Glue limitation

The managed AWS Glue Streaming job type officially supports Kinesis, Kafka, and MSK as streaming sources. Amazon S3 is supported as a streaming target. Therefore the streaming example in `glue_stream_job.py` is **Kinesis -> S3**, not S3 -> S3.

If files arriving in S3 are the source of truth, use `s3_batch_job.py` as a normal Glue Spark job and trigger it from your S3/event orchestration. Do not label that job as a native Glue Streaming source.

## Files

- `otel_tracer.py`: reusable OTLP tracing wrapper. The Glue job only imports this file.
- `glue_stream_job.py`: Glue Streaming micro-batch example using Kinesis as source and S3 as target.
- `s3_batch_job.py`: supported S3-input Glue Spark batch alternative.
- `requirements.txt`: pinned OpenTelemetry Python packages.

## Glue 5.0/5.1 dependencies

For Glue 5.0+, AWS supports `requirements.txt` through `--additional-python-modules` plus `--python-modules-installer-option=-r`. Pin versions in production.

Example arguments:

--python-modules-installer-option=-r
--additional-python-modules=s3://YOUR-BUCKET/dependencies/requirements.txt

Upload both Python scripts to S3. If the wrapper is not bundled into the same directory/package as the main script, make it available through the job's Python path.

## OTLP endpoint

`OTEL_ENDPOINT` should be the ADOT Collector HTTP traces endpoint, normally:

`http://ADOT_HOST:4318/v1/traces`

For TLS use `https://.../v1/traces`.

The collector can fan out the same trace pipeline to AWS X-Ray and Dynatrace.

## Job arguments for streaming example

--JOB_NAME=my-glue-stream
--KINESIS_STREAM_NAME=my-input-stream
--KINESIS_REGION=us-east-1
--OUTPUT_PATH=s3://my-bucket/output/
--CHECKPOINT_PATH=s3://my-bucket/checkpoints/my-glue-stream/
--OTEL_ENDPOINT=https://adot.example.internal:4318/v1/traces
--ENVIRONMENT=prod

## Why flush each micro-batch?

The wrapper uses a BatchSpanProcessor for normal operation, then calls `force_flush()` after every micro-batch. This reduces the amount of telemetry that can remain only in the Glue process if the next batch or job fails. It cannot guarantee telemetry generated at the exact instant of a hard process/node failure.
