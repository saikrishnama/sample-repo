"""Supported S3-input alternative.

Use this as a normal AWS Glue Spark batch job when new files in S3 are the
source of truth. For near-real-time processing, trigger the job from S3/EventBridge
and use Glue job bookmarks or another idempotency mechanism.
"""

from __future__ import annotations

import logging
import os
import sys

from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from pyspark.sql.functions import current_timestamp

from otel_tracer import flush_traces, init_tracing, trace_operation

logging.basicConfig(level=logging.INFO)
LOG = logging.getLogger(__name__)


def main() -> None:
    args = getResolvedOptions(
        sys.argv,
        ["JOB_NAME", "INPUT_PATH", "OUTPUT_PATH", "OTEL_ENDPOINT", "ENVIRONMENT"],
    )

    sc = SparkContext.getOrCreate()
    glue_context = GlueContext(sc)
    spark = glue_context.spark_session
    job = Job(glue_context)
    job.init(args["JOB_NAME"], args)

    job_run_id = getResolvedOptions(sys.argv, ["JOB_RUN_ID"])["JOB_RUN_ID"]
    init_tracing(args["JOB_NAME"], job_run_id, args["ENVIRONMENT"], args["OTEL_ENDPOINT"])

    try:
        with trace_operation("glue.s3.read", input_path=args["INPUT_PATH"]) as span:
            df = spark.read.json(args["INPUT_PATH"])
            count = df.count()
            span.set_attribute("aws.glue.input_records", int(count))

        with trace_operation("glue.s3.write", output_path=args["OUTPUT_PATH"]) as span:
            (
                df.withColumn("processed_at", current_timestamp())
                .write.mode("append")
                .format("parquet")
                .save(args["OUTPUT_PATH"])
            )
            span.set_attribute("aws.glue.output_path", args["OUTPUT_PATH"])

        flush_traces()
        job.commit()
    except Exception as exc:
        with trace_operation("glue.s3.job_failure") as span:
            span.record_exception(exc)
        flush_traces(10)
        raise
    finally:
        flush_traces(10)


if __name__ == "__main__":
    main()
